<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>PayArc</title>
<link href="{{asset('assets/css/bootstrap.min.css')}}" rel="stylesheet">
<link href="{{asset('assets/css/style.css')}}" rel="stylesheet">
<link href="{{asset('assets/css/custom.css')}}" rel="stylesheet">
<script src="{{asset('assets/js/jquery.min.js')}}" type="text/javascript"></script>
<script src="https://npmcdn.com/tether@1.2.4/dist/js/tether.min.js"></script>
<script src="{{asset('assets/js/bootstrap.min.js')}}" type="text/javascript"></script>
<link href="{{asset('assets/css/font-awesome.min.css')}}" rel="stylesheet">
</head>

<body>
@guest
  @else
    @include('layouts.topbar')
 

    <div class="container-fluid">
      <div class="row">
        @include('layouts.sidebar')
@endguest
@yield('content')
        @include('layouts.footer')
      
