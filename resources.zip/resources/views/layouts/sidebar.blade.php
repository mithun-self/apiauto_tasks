<nav class="col-sm-3 col-md-2 hidden-xs-down bg-faded sidebar">
          <ul class="nav nav-pills flex-column lmenu">
            <li class="nav-item">
              <a class="nav-link active lactive" href="{{url('/dashboard')}}">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="{{url('payment')}}">Payments</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="{{url('balance')}}">Balance</a>
            </li>
           
               <li data-toggle="collapse" data-target="#service" class="collapsed nav-item">
                  <a href="#" class="nav-link">Reports <i class="fa fa-angle-right"></i></a>
                </li>  
                <ul class="sub-menu collapse" id="service">
                  <li>Transaction Report</li>
                  <li>Disbursement Report</li>
                  <li>Disputes</li>
                </ul>
                <li class="nav-item">
            	  <a class="nav-link" href="{{url('customer')}}">Customers</a>
            	</li>
                <li class="nav-item">
            	  <a class="nav-link" href="{{url('fraud-reporting')}}">Fraud Reporting</a>
            	</li>
                <li class="nav-item">
            	  <a class="nav-link" href="{{url('subscriptions')}}">Subscriptions</a>
            	</li>
                <li class="nav-item">
            	  <a class="nav-link" href="{{url('products')}}">Products</a>
            	</li>
                 <li class="nav-item">
            	  <a class="nav-link" href="{{url('api')}}">API</a>
            	</li>
           		<li class="nav-item">
            	  <a class="nav-link" href="{{url('events-logs')}}">Events & Logs</a>
            	</li>
                <li class="nav-item">
            	  <a class="nav-link" href="{{url('merchant-profile')}}">Merchant Profile</a>
            	</li>



           
          </ul>

          
        </nav>